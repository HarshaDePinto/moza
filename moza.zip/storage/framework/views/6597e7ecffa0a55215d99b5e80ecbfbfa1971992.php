<?php $__env->startSection('content'); ?>
 <!-- Counts Section -->
    <section class="dashboard-counts section-padding">
        <div class="container-fluid">
            <div class="row">

                <!-- Applicants-->
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="wrapper count-title d-flex">
                        <div class="icon">
                            <i class="fa fa-users" style="color:#208000"></i>
                        </div>
                        <div class="name">
                            <strong class="text-uppercase">
                                <a class="text-success" href="<?php echo e(route('applicant.index')); ?>">Applicants
                                </a>
                            </strong>
                            <div class="count-number">
                                <?php echo e($applicants->count()); ?>

                            </div>
                        </div>
                    </div>
                </div>


                <!-- Companies-->
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="wrapper count-title d-flex">
                        <div class="icon">
                            <i class="fa fa-building" style="color:#995c00"></i>
                        </div>
                        <div class="name">
                            <strong class="text-uppercase">
                                <a class="text-success" href="<?php echo e(route('company.index')); ?>">Companies
                                </a>
                            </strong>
                            <div class="count-number">
                                <?php echo e($companies->count()); ?>

                            </div>
                        </div>
                    </div>
                </div>


                <!-- Categories-->
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="wrapper count-title d-flex">
                        <div class="icon">
                            <i class="icon-check" style="color:#ff9933"></i>
                        </div>
                        <div class="name">
                            <strong class="text-uppercase">
                                <a class="text-success" href="<?php echo e(route('category.index')); ?>">Categories
                                </a>
                            </strong>
                            <div class="count-number">
                                <?php echo e($categories->count()); ?>

                            </div>
                        </div>
                    </div>
                </div>


                <!-- Vacancies-->
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="wrapper count-title d-flex">
                        <div class="icon">
                            <i class="fa fa-newspaper-o" style="color:#ff4000" ></i>
                        </div>
                        <div class="name">
                            <strong class="text-uppercase">
                                <a class="text-success" href="<?php echo e(route('vacancy.index')); ?>">Vacancies
                                </a>
                            </strong>
                            <div class="count-number">
                                <?php echo e($vacancies->count()); ?>

                             </div>
                        </div>
                    </div>
                </div>

                <!-- Interviews-->
                <div class="col-xl-2 col-md-4 col-6">
                    <div class="wrapper count-title d-flex">
                        <div class="icon">
                            <i class="fa fa-handshake-o" style="color:#999900"></i>
                        </div>
                        <div class="name">
                            <strong class="text-uppercase">
                                <a class="text-success" href="<?php echo e(route('interview.index')); ?>">Interviews
                                </a>
                            </strong>
                            <div class="count-number">
                                <?php echo e($interviews->count()); ?>

                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </div>
    </section>


<!-- Header Section-->
    <section class="dashboard-header section-padding">
        <div class="container-fluid">
            <div class="row d-flex align-items-md-stretch">

                <!-- Applicants-->
                <div class="col-lg-3 col-md-6">
                    <div class="card project-progress">
                        <h2 class="display h4">Latest Applicants</h2>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $applicants->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('applicant.show',$applicant->id)); ?>"> <?php if($applicant->image): ?>
                            <img class="rounded-circle mr-2" width="30" src="<?php echo e(asset('storage/app/public/'.$applicant->image)); ?>" alt="No Image" >
                            <?php else: ?>
                            <img class="rounded-circle mr-2" width="30" src="<?php echo e(asset('public/img/no.png')); ?>" alt="No Image">
                            <?php endif; ?>
                            <?php echo e($applicant->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <div class="raw bg-light">
                        <a href="<?php echo e(route('applicant.create')); ?>"><i class="fa fa-plus-circle" style="font-size:28px;color:green"></i></a>
                            <a class="float-right" href="<?php echo e(route('applicant.index')); ?>"><i class="fa fa-caret-square-o-right" style="font-size:28px;color:blue"></i></a>
                        </div>



                    </div>
                </div>

                <!-- Companies-->
                <div class="col-lg-3 col-md-6">
                    <div class="card project-progress">
                        <h2 class="display h4">Latest Companies</h2>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $companies->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('company.show',$company->id)); ?>">
                            <?php echo e($company->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <div class="raw bg-light">
                        <a href="<?php echo e(route('company.create')); ?>"><i class="fa fa-plus-circle" style="font-size:28px;color:green"></i></a>
                            <a class="float-right" href="<?php echo e(route('company.index')); ?>"><i class="fa fa-caret-square-o-right" style="font-size:28px;color:blue"></i></a>
                        </div>



                    </div>
                </div>

                 <!-- Interviews-->
                <div class="col-lg-3 col-md-6">
                    <div class="card project-progress">
                        <h2 class="display h4">Latest Interviewer</h2>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $interviews->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('interview.show',$interview->id)); ?>"> <?php if($interview->applicant->image): ?>
                            <img class="rounded-circle mr-2" width="30" src="<?php echo e(asset('storage/app/public/'.$interview->applicant->image)); ?>" alt="No Image">
                            <?php else: ?>
                            <img class="rounded-circle mr-2" width="30" src="<?php echo e(asset('public/img/no.png')); ?>" alt="No Image">
                            <?php endif; ?>
                            <?php echo e($interview->applicant->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <div class="raw bg-light">
                        <a href="<?php echo e(route('interview.create')); ?>"><i class="fa fa-plus-circle" style="font-size:28px;color:green"></i></a>
                            <a class="float-right" href="<?php echo e(route('interview.index')); ?>"><i class="fa fa-caret-square-o-right" style="font-size:28px;color:blue"></i></a>
                        </div>



                    </div>
                </div>
                  <!-- Vacancies-->
                <div class="col-lg-3 col-md-6">
                    <div class="card project-progress">
                        <h2 class="display h4">Latest Vacancies</h2>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $vacancies->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('vacancy.show',$vacancy->id)); ?>">
                            <?php if($vacancy->title): ?>
                            <?php echo e($vacancy->title->name); ?>

                            <?php else: ?>
                                Not Set Yet
                            <?php endif; ?>
                            </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                        <div class="raw bg-light">
                        <a href="<?php echo e(route('vacancy.create')); ?>"><i class="fa fa-plus-circle" style="font-size:28px;color:green"></i></a>
                            <a class="float-right" href="<?php echo e(route('vacancy.index')); ?>"><i class="fa fa-caret-square-o-right" style="font-size:28px;color:blue"></i></a>
                        </div>



                    </div>
                </div>

            </div>
        </div>
    </section>

<!-- Statistics Section Optional-->
    <section class="statistics">
        <div class="container-fluid">
        <div class="row d-flex">
            <div class="col-lg-4">
            <!-- Income-->
            <div class="card income text-center">
                <div class="icon"><i class="icon-line-chart"></i></div>
                <div class="number">126,418</div><strong class="text-primary">All Income</strong>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do.</p>
            </div>
            </div>
            <div class="col-lg-4">
            <!-- Monthly Usage-->
            <div class="card data-usage">
                <h2 class="display h4">Monthly Usage</h2>
                <div class="row d-flex align-items-center">
                <div class="col-sm-6">
                    <div id="progress-circle" class="d-flex align-items-center justify-content-center"></div>
                </div>
                <div class="col-sm-6"><strong class="text-primary">80.56 Gb</strong><small>Current Plan</small><span>100
                    Gb Monthly</span></div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
            </div>
            </div>
            <div class="col-lg-4">
            <!-- User Actibity-->
            <div class="card user-activity">
                <h2 class="display h4">User Activity</h2>
                <div class="number">210</div>
                <h3 class="h4 display">Social Users</h3>
                <div class="progress">
                <div role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"
                    class="progress-bar progress-bar bg-primary"></div>
                </div>
                <div class="page-statistics d-flex justify-content-between">
                <div class="page-statistics-left"><span>Pages Visits</span><strong>230</strong></div>
                <div class="page-statistics-right"><span>New Visits</span><strong>73.4%</strong></div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('mail'); ?>
    <!-- Messages dropdown-->
    <li class="nav-item dropdown">
        <a id="messages" rel="nofollow" data-target="#" href="#"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link">
            <i class="fa fa-envelope" style="font-size:20px;color:white" ></i>
            <span class="badge badge-info">
                <?php echo e($mails->count()); ?>

            </span>
        </a>

            <ul aria-labelledby="notifications" class="dropdown-menu">
                <?php $__currentLoopData = $mails->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a rel="nofollow" href="<?php echo e(route('applicant.show',$mail->applicant->id)); ?>" class="dropdown-item d-flex">
                            <div class="msg-profile">
                                <?php if($mail->applicant->image): ?>
                                    <img class="rounded-circle mr-2" width="50" src="<?php echo e(asset('storage/app/public/'.$mail->applicant->image)); ?>" alt="No Image">
                                <?php else: ?>
                                    <img class="rounded-circle mr-2" width="50" src="<?php echo e(asset('public/img/no.png')); ?>" alt="No Image">
                                <?php endif; ?>

                            </div>
                            <div class="msg-body">
                                <h3 class="h5">
                                    <?php echo e($mail->applicant->name); ?>

                                </h3>
                                <span>
                                    <?php echo e($mail->subject); ?>

                                </span>
                                <small>
                                    <?php echo e($mail->updated_at->diffForHumans()); ?>

                                </small>
                            </div>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="raw bg-light">

                    <a class="float-right" href="<?php echo e(route('applicant.index')); ?>">
                        <i class="fa fa-caret-square-o-right" style="font-size:28px;color:blue"></i>
                    </a>
                </div>
            </ul>
    </li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/home.blade.php ENDPATH**/ ?>
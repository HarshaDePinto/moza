<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">
      <!-- Page Header-->

      <div class="row">

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h4>All Applicants</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Status</th>
                      <th>Job Title</th>
                      <th>Updated By</th>

                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th><a href="<?php echo e(route('applicant.show',$applicant->id)); ?>">
                            <?php if($applicant->image): ?>
                            <img class="rounded-circle mr-2" width="50" src="<?php echo e("storage/$applicant->image"); ?>" alt="No Image">
                            <?php else: ?>
                            <img class="rounded-circle mr-2" width="50" src="<?php echo e(asset('img/no.png')); ?>" alt="No Image">
                            <?php endif; ?>
                            <?php echo e($applicant->name); ?>

                        </a>
                        </th>
                        <td><?php echo e($applicant->status); ?></td>
                        <td>
                            <?php if($applicant->title): ?>
                            <?php echo e($applicant->title->name); ?>

                            <?php else: ?>
                                Not Set Yet
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($applicant->author); ?><br>
                            <?php echo e($applicant->updated_at->diffForHumans()); ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/applicants/index.blade.php ENDPATH**/ ?>
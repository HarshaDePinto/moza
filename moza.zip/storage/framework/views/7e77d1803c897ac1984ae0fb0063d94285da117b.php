<?php $__env->startSection('content'); ?>




<!-- Header Section-->
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
        <a class="navbar-brand" href="<?php echo e(route('stuLev.index')); ?>"><i class="fa fa-caret-square-o-left" style="font-size:20px"></i></a>
        <a class="navbar-brand" href="#top">Top</a>

        <a class="navbar-brand" href="#Subjects">Subjects</a>
        <a class="navbar-brand" href="#Interviews">Interviews</a>
        <a class="navbar-brand" href="#Hired">Hired</a>
        <a class="navbar-brand" href="#Hired">Job titels</a>

        
    </nav>

    <section id="top" class="dashboard-header section-padding">


        <h1 class="text-primary text-center mb-4"></h1>
        <div class="container-fluid">
            <div class="row d-flex align-items-md-stretch">

            <!-- Description-->
                <div class="col-lg-8 col-md-8">
                    <div class="card to-do">
                        <h3><?php echo e($level->name); ?></h3>
                        <div class="container">
                            <?php echo $level->des; ?>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="card to-do">
                    <a class="btn text-white my-2" style="background-color:#FF851B;" href="<?php echo e(route('addSub',$level->id)); ?>">
                            Add A Subject
                        </a>
                        <a class="btn text-white my-2" style="background-color:#0040ff;" href="#Vacancies">
                            Add A Colleges
                        </a>
                        <a class="btn btn-success text-white my-2" href="">
                            Students

                        </a>
                        <a class="btn btn-danger text-white my-2" href="">
                            Cources
                        </a>
                    </div>
                </div>
            <!-- Work History-->

        </div>
        </div>
    </section>


<!-- Statistics Section-->
<section id="Subjects" class="dashboard-header section-padding">


    <h1 class="text-primary text-center mb-4"></h1>
    <div class="container-fluid">
        <div class="row d-flex align-items-md-stretch">

        <!-- Description-->

                <div class="card to-do">
                    <h2>All Subjects</h2>
                    <?php if($level->subjects->count()>0): ?>
                    <ul>
                        <?php $__currentLoopData = $level->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($sub->name); ?>


                    </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php else: ?>
                    <h3>No Subjects</h3>
                    <?php endif; ?>

                </div>


        <!-- Work History-->

    </div>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adStudent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/students/admin/levels/single.blade.php ENDPATH**/ ?>
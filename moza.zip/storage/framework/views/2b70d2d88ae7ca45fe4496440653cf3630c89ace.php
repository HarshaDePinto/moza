<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <!-- Page Header-->

        <div class="row">

          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <h4>All Users</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Status</th>
                        <th>Update By</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <a href="<?php echo e(route('user.show',$user->id)); ?>">
                            <?php if($user->image): ?>
                            <img class="rounded-circle mr-2" width="50" src="<?php echo e(asset('storage/app/public/'.$user->image)); ?>" alt="No Image">
                            <?php else: ?>
                            <img class="rounded-circle mr-2" width="50" src="<?php echo e(asset('public/img/no.png')); ?>" alt="No Image">
                            <?php endif; ?>
                            </a>
                          </td>
                          <td>
                            <a href="<?php echo e(route('user.show',$user->id)); ?>">
                            <?php echo e($user->name); ?>

                            </a>
                          </td>

                          <td>
                            <?php echo e($user->position); ?>

                          </td>
                          <td>
                              <?php if($user->is_active==1): ?>
                                  Active
                              <?php else: ?>
                                  Inactive
                              <?php endif; ?>
                          </td>

                          <td>
                            <?php echo e($user->updated_at->diffForHumans()); ?><br> <?php echo e($user->author); ?>


                          </td>


                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/admin/users/index.blade.php ENDPATH**/ ?>
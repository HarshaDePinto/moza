<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">

        <div class="card">
            <div class="card-header d-flex align-items-center">
              <h4><a class="navbar-brand" href="<?php echo e(route('company.index')); ?>"><i class="fa fa-caret-square-o-left" style="font-size:20px"></i></a> <i class="icon-check"></i> Find A Company</h4>
            </div>
            <div class="card-body">
              <form class="form-inline" action="<?php echo e(route('cpName')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="alert-group">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="alert-group-item text-danger">
                                    <h3><?php echo e($error); ?></h3>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                  <label for="name" class="sr-only">Company Name</label>
                  <input id="name" name="name" type="text"  class="mr-3 form-control">
                </div>

                <div class="form-group">

                  <button type="submit" class="mr-3 btn btn-primary"> <i class="fa fa-search" style="font-size:48px"></i></button>
                </div>
              </form>
            </div>
          </div>
    </div>

    <div class="container-fluid">
      <!-- Page Header-->

      <div class="row">

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h4>All Companies</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th>Ref.</th>
                      <th>Name</th>
                      <th>Reg.No</th>
                      <th>Categories</th>
                      <th>Updated By</th>

                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($company->regNumber); ?></td>
                        <th><a href="<?php echo e(route('company.show',$company->id)); ?>">

                            <?php echo e($company->name); ?>

                        </a>
                        </th>
                        <td><?php echo e($company->reg); ?></td>
                        <td>
                           <?php if($company->categories): ?>
                           <ul>
                               <?php $__currentLoopData = $company->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <li>
                                   <?php echo e($category->name); ?>


                                </li>


                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                           <?php else: ?>
                               Not Set Yet
                           <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($company->author); ?><br>
                            <?php echo e($company->updated_at->diffForHumans()); ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/companies/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="raw">
            <div class="col-lg-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center">

                    <h4 class="ml-4">New Vacancy</h4>

                  </div>
                  <div class="card-body">


                    <form class="form-horizontal" action="<?php echo e(route('vacancyDescription',$vacancy->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>



                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="alert-group">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="alert-group-item text-danger">
                                             <h3><?php echo e($error); ?></h3>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                      <div class="form-group row">
                        <h3 class="display h4">Job Category <span class="text-info"><?php echo e($vacancy->category->name); ?></span></h3>




                      </div>


                      <div class="form-group row">


                        <h3 class="display h4">Job Title <span class="text-info"><?php echo e($vacancy->title->name); ?></span></h3>


                      </div>




                      <div class="line"></div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label" for="company_id">Company Name</label>
                      <div class="col-sm-10 mb-3">
                        <select name="company_id" class="form-control" id="company_id">
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->id); ?>">

                            <?php echo e($company->name); ?>

                            </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                      </div>
                    </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="number">Number Of Vacancies </label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="number" placeholder="Number only No latters" required>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="time">Working Houres</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="time">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="salary">Salary Range</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="salary">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="gender">Gender Preference</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="gender">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="start">Open Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="start">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="end">Closed Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="end">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="des">Job Description</label>
                        <div class="col-sm-10">
                            <input id="des" type="hidden" name="des">
                            <trix-editor input="des"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="edu">Educational qualifications</label>
                        <div class="col-sm-10">
                            <input id="edu" type="hidden" name="edu">
                            <trix-editor input="edu"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="ben">Other Benifits</label>
                        <div class="col-sm-10">
                            <input id="ben" type="hidden" name="ben">
                            <trix-editor input="ben"></trix-editor>
                        </div>
                      </div>


                            <input id="author" type="text" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>" hidden>


                      <div class="line"></div>
                      <div class="form-group row ">
                        <div class="col-sm-4 offset-sm-2">

                          <button type="submit" class="btn btn-primary ">Add The Vacancy</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/vacancies/description.blade.php ENDPATH**/ ?>
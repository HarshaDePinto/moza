<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">
      <!-- Page Header-->

      <div class="row">

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h4>All Vacancies</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                    <th>Title</th>
                      <th>Category</th>

                      <th>Company</th>
                      <th>Updated By</th>

                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th><a href="<?php echo e(route('vacancy.show',$vacancy->id)); ?>">

                            <?php echo e($vacancy->title->name); ?>

                        </a>
                        </th>
                        <td><?php echo e($vacancy->category->name); ?></td>
                        <td>
                            <?php echo e($vacancy->company->name); ?>

                        </td>

                        <td>
                            <?php echo e($vacancy->author); ?><br>
                            <?php echo e($vacancy->updated_at->diffForHumans()); ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/vacancies/index.blade.php ENDPATH**/ ?>
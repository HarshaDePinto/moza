Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo $body; ?></p>

<h1 class="text-success text-center">Thank You!</h1>
<h2 class="text-info text-center">For More Info Please Visit</h2>
<h1 class=" text-center"><a href="https://mozita.co.nz/">Mozita</a></h1>
<?php /**PATH C:\xampp\htdocs\moza\resources\views/emails/mail.blade.php ENDPATH**/ ?>
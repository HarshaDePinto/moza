<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="card">
            <div class="card-header d-flex align-items-center">
              <h4> <i class="icon-check"></i> Add Job Title</h4>
            </div>
            <div class="card-body">
              <form class="form-inline" action="<?php echo e(route('title.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="alert-group">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="alert-group-item text-danger">
                                    <h3><?php echo e($error); ?></h3>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                  <label for="name" class="sr-only">Job Title</label>
                  <input id="name" name="name" type="text"  class="mr-3 form-control">
                </div>

                <div class="form-group">
                    <label for="category_id" class="sr-only">Job Category</label>

                    <select name="category_id" class="form-control" id="category_id">

                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" >

                        <?php echo e($category->name); ?>

                        </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                  </div>


                  <input id="author" name="author" type="text"  value="<?php echo e(Auth::user()->name); ?>" hidden>
                <div class="form-group ml-2">
                  <input type="submit" value="Add" class="mr-3 btn btn-primary">
                </div>
              </form>
            </div>
          </div>
    </div>

    <div class="container-fluid">
        <!-- Page Header-->

        <div class="row">

          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">
                <h4>All Job Titles</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th>Job Titles</th>
                        <th>Category</th>
                        <th>Delete</th>
                        <th>Updated By</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th><?php echo e($title->name); ?>


                          </th>
                          <td>
                            <?php echo e($title->category->name); ?>


                          </td>

                          <td>
                            <a href="" class="btn btn-danger btn-sm"  onclick="handleDelete(<?php echo e($title->id); ?>)" data-toggle="modal" data-target="#deleteModal<?php echo e($title->id); ?>">Delete</a>

                            <form action="" method="POST" id="deleteTitle">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                            <div class="modal fade" id="deleteModal<?php echo e($title->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="deleteModalLabel"> <?php echo e($title->name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">

                                    <p>Are You Sure To Delete?</p>

                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-success" data-dismiss="modal">No Go Back</button>
                                    <button type="submit" class="btn btn-danger">Yes Delete</button>
                                    </div>
                                </div>
                                </div>
                            </div>

                          </td>

                          <td>
                            <?php echo e($title->updated_at->diffForHumans()); ?><br> <?php echo e($title->author); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    function handleDelete(id){

        var form = document.getElementById('deleteTitle')
        form.action='/title/'+id

    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/titles/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="raw">
            <div class="col-lg-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center">

                    <h4 class="ml-4">
                        <?php if(isset($vacancy)): ?>
                            <?php if($vacancy->title): ?>
                            <?php echo e($vacancy->title->name); ?>

                            <?php else: ?>
                                Not Set Yet
                            <?php endif; ?>

                        <?php else: ?>
                                New Vacancy
                        <?php endif; ?>

                        </h4>

                  </div>
                  <div class="card-body">


                    <form class="form-horizontal" action="<?php echo e(isset($vacancy)?route('vacancy.update',$vacancy->id):route('vacancyDescription',$vacancy->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($vacancy)): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>


                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="alert-group">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="alert-group-item text-danger">
                                             <h3><?php echo e($error); ?></h3>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                      <div class="form-group row">
                          <?php if(isset($vacancy)): ?>

                            <label class="col-sm-2 form-control-label" for="category_id">Job Category</label>
                            <div class="col-sm-10 mb-3">
                              <select name="category_id" class="form-control" id="category_id">

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                            <?php if(isset($vacancy->category)): ?>
                                            <?php if($category->id==$vacancy->category->id): ?>
                                            selected
                                            <?php endif; ?>

                                            <?php endif; ?>

                                            >

                                    <?php echo e($category->name); ?>

                                    </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </select>

                            </div>

                          <?php else: ?>
                          <h3 class="display h4">Job Category <span class="text-info"><?php echo e($vacancy->category->name); ?></span></h3>
                          <?php endif; ?>





                      </div>


                      <div class="form-group row">
                        <?php if(isset($vacancy)): ?>
                        <label class="col-sm-2 form-control-label" for="title_id">Job Title</label>
                        <div class="col-sm-10 mb-3">
                          <select name="title_id" class="form-control" id="title_id">

                                <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($title->id); ?>"
                                        <?php if(isset($vacancy->title)): ?>
                                        <?php if($title->id==$vacancy->title->id): ?>
                                        selected
                                        <?php endif; ?>

                                        <?php endif; ?>

                                        >

                                <?php echo e($title->name); ?>

                                </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>

                        </div>
                        <?php else: ?>
                        <h3 class="display h4">Job Title <span class="text-info"><?php echo e($vacancy->title->name); ?></span></h3>
                        <?php endif; ?>




                      </div>




                      <div class="line"></div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label" for="company_id">Company Name</label>
                      <div class="col-sm-10 mb-3">
                        <select name="company_id" class="form-control" id="company_id">
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($company->id); ?>">

                            <?php echo e($company->name); ?>

                            </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                      </div>
                    </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="number">Number Of Vacancies </label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="number" placeholder="Number only No latters" value="<?php echo e(isset($vacancy)?$vacancy->number:''); ?>" required>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="time">Working Houres</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="time" value="<?php echo e(isset($vacancy)?$vacancy->time:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="salary">Salary Range</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="salary" value="<?php echo e(isset($vacancy)?$vacancy->salary:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="gender">Gender Preference</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="gender" value="<?php echo e(isset($vacancy)?$vacancy->gender:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="start">Open Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="start" value="<?php echo e(isset($vacancy)?$vacancy->start:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="end">Closed Date</label>
                        <div class="col-sm-10">
                          <input type="date" class="form-control" name="end" value="<?php echo e(isset($vacancy)?$vacancy->end:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="des">Job Description</label>
                        <div class="col-sm-10">
                            <input id="des" type="hidden" name="des" value="<?php echo e(isset($vacancy)?$vacancy->des:''); ?>">
                            <trix-editor input="des"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="edu">Educational qualifications</label>
                        <div class="col-sm-10">
                            <input id="edu" type="hidden" name="edu" value="<?php echo e(isset($vacancy)?$vacancy->edu:''); ?>">
                            <trix-editor input="edu"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="ben">Other Benifits</label>
                        <div class="col-sm-10">
                            <input id="ben" type="hidden" name="ben" value="<?php echo e(isset($vacancy)?$vacancy->ben:''); ?>">
                            <trix-editor input="ben"></trix-editor>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="note">Note</label>
                        <div class="col-sm-10">
                            <input id="note" type="hidden" name="note" value="<?php echo e(isset($vacancy)?$vacancy->note:''); ?>">
                            <trix-editor input="note"></trix-editor>
                        </div>
                      </div>


                            <input id="author" type="text" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>" hidden>


                      <div class="line"></div>
                      <div class="form-group row ">
                        <div class="col-sm-4 offset-sm-2">

                          <button type="submit" class="btn btn-primary "><?php echo e(isset($vacancy)?'Save changes':'Add Vacancy'); ?></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/vacancies/description.blade.php ENDPATH**/ ?>
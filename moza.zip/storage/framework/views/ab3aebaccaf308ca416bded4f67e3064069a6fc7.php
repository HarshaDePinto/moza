<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">
      <!-- Page Header-->

      <div class="row">

        <div class="col-lg-12">
            <div id="main_place">
                <div class="card">
                    <div class="card-header">
                    <h4><button style="background-color:#0066ff ;" class="btn   text-white" onclick="show('operation1')"><i class="fas fa-user-tie"></i>On Going Vacancies</button> <button style="background-color:#ff9933 ;" class="btn   text-white" onclick="show('operation2')"><i class="fas fa-user-tie"></i>Closed Vacancies</button></h4>
                    </div>
                    <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                            <th>Ref.</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Company</th>
                            <th>Updated By</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($vacancy->end>=date('Y-m-d')): ?>

                            <tr>
                                <th><?php echo e($vacancy->regNumber); ?></th>
                                <th><a href="<?php echo e(route('vacancy.show',$vacancy->id)); ?>">
                                    <?php if($vacancy->title): ?>
                                    <?php echo e($vacancy->title->name); ?>

                                    <?php else: ?>
                                        Not Set Yet
                                    <?php endif; ?>
                                </a>
                                </th>
                                <td> <?php if($vacancy->category): ?>
                                    <?php echo e($vacancy->category->name); ?>

                                    <?php else: ?>
                                        Not Set Yet
                                    <?php endif; ?>
                                    </td>
                                <td>
                                    <?php if($vacancy->company): ?>
                                    <a href="<?php echo e(route('company.show',$vacancy->company->id)); ?>">
                                    <?php echo e($vacancy->company->name); ?>

                                    </a>
                                    <?php else: ?>
                                        Not Set Yet
                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?php echo e($vacancy->author); ?><br>
                                    <?php echo e($vacancy->updated_at->diffForHumans()); ?>

                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </div>
</section>
<div id="operation1" style="display:none">
    <div class="card">
        <div class="card-header">
        <h4><button style="background-color:#0066ff ;" class="btn   text-white" onclick="show('operation1')"><i class="fas fa-user-tie"></i>Ongoing Vacancies</button> <button style="background-color:#ff9933 ;" class="btn   text-white" onclick="show('operation2')"><i class="fas fa-user-tie"></i>Closed Vacancies</button></h4>
        <br>
        <h4>Ongoing Vacancies</h4>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
            <thead>
                <tr>
                <th>Ref.</th>
                <th>Title</th>
                <th>Category</th>
                <th>Company</th>
                <th>Updated By</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($vacancy->end>=date('Y-m-d')): ?>

                <tr>
                    <th><?php echo e($vacancy->regNumber); ?></th>
                    <th><a href="<?php echo e(route('vacancy.show',$vacancy->id)); ?>">
                        <?php if($vacancy->title): ?>
                        <?php echo e($vacancy->title->name); ?>

                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>
                    </a>
                    </th>
                    <td> <?php if($vacancy->category): ?>
                        <?php echo e($vacancy->category->name); ?>

                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>
                        </td>
                    <td>
                        <?php if($vacancy->company): ?>
                        <a href="<?php echo e(route('company.show',$vacancy->company->id)); ?>">
                        <?php echo e($vacancy->company->name); ?>

                        </a>
                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>

                    </td>

                    <td>
                        <?php echo e($vacancy->author); ?><br>
                        <?php echo e($vacancy->updated_at->diffForHumans()); ?>

                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
            </table>
        </div>
        </div>
    </div>
</div>

<div id="operation2" style="display:none">
    <div class="card">
        <div class="card-header">
        <h4><button style="background-color:#0066ff ;" class="btn   text-white" onclick="show('operation1')"><i class="fas fa-user-tie"></i>Ongoing Vacancies</button> <button style="background-color:#ff9933 ;" class="btn   text-white" onclick="show('operation2')"><i class="fas fa-user-tie"></i>Closed Vacancies</button></h4>
        <br>
        <h4>Closed Vacancies</h4>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
            <thead>
                <tr>
                <th>Ref.</th>
                <th>Title</th>
                <th>Category</th>
                <th>Company</th>
                <th>Updated By</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($vacancy->end<date('Y-m-d')): ?>

                <tr>
                    <th><?php echo e($vacancy->regNumber); ?></th>
                    <th><a href="<?php echo e(route('vacancy.show',$vacancy->id)); ?>">
                        <?php if($vacancy->title): ?>
                        <?php echo e($vacancy->title->name); ?>

                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>
                    </a>
                    </th>
                    <td> <?php if($vacancy->category): ?>
                        <?php echo e($vacancy->category->name); ?>

                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>
                        </td>
                    <td>
                        <?php if($vacancy->company): ?>
                        <a href="<?php echo e(route('company.show',$vacancy->company->id)); ?>">
                        <?php echo e($vacancy->company->name); ?>

                        </a>
                        <?php else: ?>
                            Not Set Yet
                        <?php endif; ?>

                    </td>

                    <td>
                        <?php echo e($vacancy->author); ?><br>
                        <?php echo e($vacancy->updated_at->diffForHumans()); ?>

                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
            </table>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        function show(param_div_id) {
        document.getElementById('main_place').innerHTML = document.getElementById(param_div_id).innerHTML;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moza\resources\views/admin/vacancies/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="raw">
            <div class="col-lg-12">
                <div class="card">
                  <div class="card-header d-flex align-items-center">
                    <?php if(isset($applicant)): ?>
                    <a href="<?php echo e(route('applicant.show',$applicant->id)); ?>"><i class="fa fa-caret-square-o-left" style="font-size:20px"></i> </a>
                    <?php endif; ?>
                    <h4 class="ml-4"><?php echo e(isset($applicant)?'Edit Applicant':'Add New Applicant'); ?></h4>

                  </div>
                  <div class="card-body">


                    <form class="form-horizontal" action="<?php echo e(isset($applicant)?route('applicant.update',$applicant->id):route('applicant.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <?php if(isset($applicant)): ?>
                        <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="alert-group">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="alert-group-item text-danger">
                                             <h3><?php echo e($error); ?></h3>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>



                    <div class="line"></div>
                    <div class="form-group row">
                      <label class="col-sm-2 form-control-label" for="status">Status</label>
                      <div class="col-sm-10 mb-3">
                        <select name="status" class="form-control" id="status">

                        <option value="Processing">

                            Processing
                            </option>
                            <option value="Hired">

                                Hired
                                </option>
                                <option value="Rejected">

                                    Rejected
                                    </option>



                        </select>

                      </div>
                    </div>
                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="name">Applicant Name <br><small class="text-primary">Full Name</small></label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="name" value="<?php echo e(isset($applicant)?$applicant->name:''); ?>" required >
                        </div>
                      </div>

                      

                      <div class="line"></div>
                    <div class="form-group row">
                      <label for="profile" class="col-sm-2 form-control-label">Applicant Profile <br><small class="text-primary">currently employed?</small></label>
                      <div class="col-sm-10">
                        <?php if(isset($applicant)): ?>
                            <?php if($applicant->profile=='Yes'): ?>
                            <div>
                                <input id="optionsRadios1" type="radio"  value="Yes" name="profile" checked>
                                <label for="optionsRadios1">Yse</label>
                              </div>
                              <div>
                                <input id="optionsRadios2" type="radio" value="No" name="profile">
                                <label for="optionsRadios2">No</label>
                              </div>
                            <?php else: ?>
                            <div>
                                <input id="optionsRadios1" type="radio"  value="Yes" name="profile">
                                <label for="optionsRadios1">Yse</label>
                              </div>
                              <div>
                                <input id="optionsRadios2" type="radio" value="No" name="profile" checked>
                                <label for="optionsRadios2">No</label>
                              </div>
                            <?php endif; ?>

                        <?php else: ?>
                        <div>
                            <input id="optionsRadios1" type="radio"  value="Yes" name="profile">
                            <label for="optionsRadios1">Yse</label>
                          </div>
                          <div>
                            <input id="optionsRadios2" type="radio" value="No" name="profile">
                            <label for="optionsRadios2">No</label>
                          </div>
                        <?php endif; ?>

                      </div>
                    </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="country">Applicant Country </label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="country" value="<?php echo e(isset($applicant)?$applicant->country:''); ?>" required>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="email">Applicant Email </label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="email" value="<?php echo e(isset($applicant)?$applicant->email:''); ?>" required>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="tel">Tel</label>
                        <div class="col-sm-10">
                            <input id="tel" type="hidden" name="tel" value="<?php echo e(isset($applicant)?$applicant->tel:''); ?>">
                            <trix-editor input="tel"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="experience">Experience<br><small class="text-primary">Please Enter Number Of Months</small></label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="Only a Number No Letters" class="form-control" name="experience" value="<?php echo e(isset($applicant)?$applicant->experience:''); ?>" required>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="c_job">Applicant Current Job</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="c_job" value="<?php echo e(isset($applicant)?$applicant->c_job:''); ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="c_company">Applicant Current Company</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="c_company" value="<?php echo e(isset($applicant)?$applicant->c_company:''); ?>">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="c_jd">Current Job Description</label>
                        <div class="col-sm-10">
                            <input id="c_jd" type="hidden" name="c_jd" value="<?php echo e(isset($applicant)?$applicant->c_jd:''); ?>">
                            <trix-editor input="c_jd"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="education">Educational Qualification</label>
                        <div class="col-sm-10">
                            <input id="education" type="hidden" name="education" value="<?php echo e(isset($applicant)?$applicant->education:''); ?>">
                            <trix-editor input="education"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="technical">Technical Qualification</label>
                        <div class="col-sm-10">
                            <input id="technical" type="hidden" name="technical" value="<?php echo e(isset($applicant)?$applicant->technical:''); ?>">
                            <trix-editor input="technical"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="history">Work History</label>
                        <div class="col-sm-10">
                            <input id="history" type="hidden" name="history" value="<?php echo e(isset($applicant)?$applicant->history:''); ?>">
                            <trix-editor input="history"></trix-editor>
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="image">Applicant Image</label>
                        <div class="col-sm-10">
                          <input type="file" class="form-control" name="image" id="image">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="cv">Applicant CV <br> <small class="text-danger">*pdf only</small></label>
                        <div class="col-sm-10">
                          <input type="file" class="form-control" name="cv" id="cv">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="cl">Applicant Cover Letter<br> <small class="text-danger">*pdf only</small></label>
                        <div class="col-sm-10">
                          <input type="file" class="form-control" name="cl" id="cl">
                        </div>
                      </div>

                      <div class="form-group row">
                        <label class="col-sm-2 form-control-label" for="ot">Applicant Other Document<br> <small class="text-danger">*pdf only</small></label>
                        <div class="col-sm-10">
                          <input type="file" class="form-control" name="ot" id="ot">
                        </div>
                      </div>




                            <input id="author" type="text" class="form-control" name="author" value="<?php echo e(Auth::user()->name); ?>" hidden>


                      <div class="line"></div>
                      <div class="form-group row ">
                        <div class="col-sm-4 offset-sm-2">

                          <button type="submit" class="btn btn-primary "><?php echo e(isset($applicant)?'Save changes':'Add Applicant'); ?></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/applicants/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<section>
    <div class="container-fluid">
      <!-- Page Header-->

      <div class="row">

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <h4>All Companies</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Reg.No</th>
                      <th>Categories</th>
                      <th>Updated By</th>

                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th><a href="<?php echo e(route('company.show',$company->id)); ?>">

                            <?php echo e($company->name); ?>

                        </a>
                        </th>
                        <td><?php echo e($company->reg); ?></td>
                        <td>
                           <?php if($company->categories): ?>
                           <ul>
                               <?php $__currentLoopData = $company->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <li>
                                   <?php echo e($category->name); ?>


                                </li>


                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                           <?php else: ?>
                               Not Set Yet
                           <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($company->author); ?><br>
                            <?php echo e($company->updated_at->diffForHumans()); ?>

                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mozita\resources\views/companies/index.blade.php ENDPATH**/ ?>
<strong>We warmly well come you to Mozita Student Visa Services</strong>

<img src="<?php echo e(asset('public/moza/img/study/s1.jpg')); ?>" class="img-fluid" alt="Responsive image">

<h2 class="text-info text-center">For More Info Please Visit</h2>
<h1 class=" text-center"><a href="https://mozita.co.nz/">Mozita-Group</a></h1>
<?php /**PATH C:\xampp\htdocs\moza\resources\views/admin/emails/student.blade.php ENDPATH**/ ?>
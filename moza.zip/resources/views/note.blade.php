<div class="faq-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Faq Question</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="faq-details">
            <div class="panel-group" id="accordion">
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
											<a data-toggle="collapse" class="active" data-parent="#accordion" href="#check1">
                                                <span class="acc-icons"></span>Consectetur adipisicing elit.
											</a>
										</h4>
                </div>
                <div id="check1" class="panel-collapse collapse in">
                  <div class="panel-body">
                    <p>
                      Redug Lefes dolor sit amet, consectetur adipisicing elit. Aspernatur, tempore, commodi quas mollitia dolore magnam quidem repellat, culpa voluptates laboriosam maiores alias accusamus recusandae vero
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#check2">
                                                <span class="acc-icons"></span> Dolore magnam quidem repellat.
											</a>
										</h4>
                </div>
                <div id="check2" class="panel-collapse collapse">
                  <div class="panel-body">
                    <p>
                      Redug Lefes dolor sit amet, consectetur adipisicing elit. Aspernatur, tempore, commodi quas mollitia dolore magnam quidem repellat, culpa voluptates laboriosam maiores alias accusamus recusandae vero aperiam sint nulla beatae eos.
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#check3">
                                                <span class="acc-icons"></span>Redug Lefes dolor sit.
											</a>
										</h4>
                </div>
                <div id="check3" class="panel-collapse collapse ">
                  <div class="panel-body">
                    <p>
                      Redug Lefes dolor sit amet, consectetur adipisicing elit. Aspernatur, tempore, commodi quas mollitia dolore magnam quidem repellat, culpa voluptates laboriosam maiores alias accusamus recusandae vero aperiam sint nulla beatae eos.
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#check4">
                                                <span class="acc-icons"></span>Maiores alias accusamus
											</a>
										</h4>
                </div>
                <div id="check4" class="panel-collapse collapse">
                  <div class="panel-body">
                    <p>
                      Redug Lefes dolor sit amet, consectetur adipisicing elit. Aspernatur, tempore, commodi quas mollitia dolore magnam quidem repellat, culpa voluptates laboriosam maiores alias accusamus recusandae vero aperiam sint nulla beatae eos.
                    </p>
                  </div>
                </div>
              </div>
              <!-- End Panel Default -->
            </div>
          </div>
        </div>

      </div>
      <!-- end Row -->
    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="faq-details">
      <div class="panel-group" id="accordion">
        <!-- Panel Default -->
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="check-title">
                                      <a data-toggle="collapse" class="active" data-parent="#accordion" href="#check1">
                                          <span class="acc-icons"></span>Consectetur adipisicing elit.
                                      </a>
                                  </h4>
          </div>
          <div id="check1" class="panel-collapse collapse in">
            <div class="panel-body">

            </div>
          </div>
        </div>
        <!-- End Panel Default -->
        <!-- Panel Default -->
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="check-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#check2">
                                          <span class="acc-icons"></span> Dolore magnam quidem repellat.
                                      </a>
                                  </h4>
          </div>
          <div id="check2" class="panel-collapse collapse">
            <div class="panel-body">

            </div>
          </div>
        </div>
        <!-- End Panel Default -->
        <!-- Panel Default -->
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="check-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#check3">
                                          <span class="acc-icons"></span>Redug Lefes dolor sit.
                                      </a>
                                  </h4>
          </div>
          <div id="check3" class="panel-collapse collapse ">
            <div class="panel-body">

            </div>
          </div>
        </div>
        <!-- End Panel Default -->
        <!-- Panel Default -->
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="check-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#check4">
                                          <span class="acc-icons"></span>Maiores alias accusamus
                                      </a>
                                  </h4>
          </div>
          <div id="check4" class="panel-collapse collapse">
            <div class="panel-body">

            </div>
          </div>
        </div>
        <!-- End Panel Default -->
      </div>
    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="tab-menu">
      <!-- Nav tabs -->
      <ul class="nav nav-tabs" role="tablist">
        <li class="active">
          <a href="#p-view-1" role="tab" data-toggle="tab">Quality education</a>
        </li>
        <li>
          <a href="#p-view-2" role="tab" data-toggle="tab">A relaxed student lifestyle</a>
        </li>
        <li>
          <a href="#p-view-3" role="tab" data-toggle="tab">Friendly locals</a>
        </li>
      </ul>
    </div>
    <div class="tab-content">
      <div class="tab-pane active" id="p-view-1">
        <div class="tab-inner">
          <div class="event-content head-team">

            <h4>Quality of Education</h4>

                <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>



          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-2">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>A relaxed student lifestyle</h4>
            <div class="row">
                <div class="col-sm-4">

                </div>
                <div class="col-sm-6">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </div>
            </div>

          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-3">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>Success</h4>

          </div>
        </div>
      </div>
    </div>
</div>

<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="tab-menu">
      <!-- Nav tabs -->
      <ul class="nav nav-tabs" role="tablist">
        <li class="active">
          <a href="#p-view-21" role="tab" data-toggle="tab">	Certificate</a>
        </li>
        <li>
          <a href="#p-view-22" role="tab" data-toggle="tab">	Diploma</a>
        </li>
        <li>
          <a href="#p-view-23" role="tab" data-toggle="tab">Under Graduate</a>
        </li>
        <li>
            <a href="#p-view-24" role="tab" data-toggle="tab">Master's degree</a>
        </li>
        <li>
            <a href="#p-view-25" role="tab" data-toggle="tab">Doctoral degree</a>
        </li>


      </ul>
    </div>
    <div class="tab-content">
      <div class="tab-pane active" id="p-view-21">
        <div class="tab-inner">
          <div class="event-content head-team">

            <h4>Certificate</h4>
            <div class="row">
                <div class="col-sm-8">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
                <div class="col-sm-4">
                    <img src="{{ asset('public/moza/img/study/s1.jpg') }}" class="img-fluid" alt="Responsive image">
                </div>

            </div>
            <div class="row">

                <div class="col-sm-12">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                    <img src="{{ asset('public/moza/img/study/s2.jpg') }}" class="img-fluid " alt="Responsive image">
                    </div>
                </div>

            </div>

          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-22">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>Diploma</h4>
            <div class="row">
                <div class="col-sm-8">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
                <div class="col-sm-4">
                    <img src="{{ asset('public/moza/img/study/s1.jpg') }}" class="img-fluid" alt="Responsive image">
                </div>

            </div>
            <div class="row">

                <div class="col-sm-12">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                    <img src="{{ asset('public/moza/img/study/s2.jpg') }}" class="img-fluid " alt="Responsive image">
                    </div>
                </div>

            </div>

          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-23">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>Under Graduate</h4>
            <div class="row">
                <div class="col-sm-8">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
                <div class="col-sm-4">
                    <img src="{{ asset('public/moza/img/study/s1.jpg') }}" class="img-fluid" alt="Responsive image">
                </div>

            </div>
            <div class="row">

                <div class="col-sm-12">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                    <img src="{{ asset('public/moza/img/study/s2.jpg') }}" class="img-fluid " alt="Responsive image">
                    </div>
                </div>

            </div>
          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-24">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>Master's degree</h4>
            <div class="row">
                <div class="col-sm-8">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
                <div class="col-sm-4">
                    <img src="{{ asset('public/moza/img/study/s1.jpg') }}" class="img-fluid" alt="Responsive image">
                </div>

            </div>
            <div class="row">

                <div class="col-sm-12">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                    <img src="{{ asset('public/moza/img/study/s2.jpg') }}" class="img-fluid " alt="Responsive image">
                    </div>
                </div>

            </div>
          </div>
        </div>
      </div>
      <div class="tab-pane" id="p-view-25">
        <div class="tab-inner">
          <div class="event-content head-team">
            <h4>Doctoral degree</h4>
            <div class="row">
                <div class="col-sm-8">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
                <div class="col-sm-4">
                    <img src="{{ asset('public/moza/img/study/s1.jpg') }}" class="img-fluid" alt="Responsive image">
                </div>

            </div>
            <div class="row">

                <div class="col-sm-12">
                    <p class="a">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="text-center">
                    <img src="{{ asset('public/moza/img/study/s2.jpg') }}" class="img-fluid " alt="Responsive image">
                    </div>
                </div>

            </div>
          </div>
        </div>
      </div>

    </div>
</div>

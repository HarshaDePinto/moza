Hello <strong>{{ $name }}</strong>,
<p>{!!$body!!}</p>


<h2 class="text-info text-center">For More Info Please Visit</h2>
<h1 class=" text-center"><a href="https://mozita.co.nz/">Mozita</a></h1>

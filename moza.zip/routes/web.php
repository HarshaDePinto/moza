<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('welcome');


Auth::routes();

//FrontEnd New Zealand
Route::get('/NewZealand', 'MozaController@newZealand')->name('newZealand');
Route::get('/NewZealand/Visa', 'MozaController@newZealandVisa')->name('newZealandVisa');

Route::middleware(['auth'])->group(function () {
    Route::get('/home', 'HomeController@index')->name('home');

    Route::resource('applicant', 'ApplicantController');
    Route::get('applicant/{applicant}/makeCategory', 'ApplicantController@makeCategory')->name('makeCategory');
    Route::post('applicant/{applicant}/setCategory', 'ApplicantController@setCategory')->name('setCategory');
    Route::post('applicant/{applicant}/makeTitle', 'ApplicantController@makeTitle')->name('makeTitle');

    Route::resource('category', 'CategoryController');

    Route::resource('company', 'CompanyController');
    Route::get('company/{company}/makeCategory', 'CompanyController@makeCategory')->name('makeCCategory');
    Route::post('company/{company}/setCategory', 'CompanyController@setCategory')->name('setCCategory');

    Route::resource('title', 'TitleController');

    Route::resource('user', 'AdminUserController');
    Route::get('users/{user}/changePassword', 'AdminUserController@changePassword')->name('user.changePassword');
    Route::put('users/{user}/login', 'AdminUserController@login')->name('user.login');

    Route::resource('vacancy', 'VacancyController');
    Route::post('vacancy/{vacancy}/vacancyTitle', 'VacancyController@vacancyTitle')->name('vacancyTitle');
    Route::post('vacancy/{vacancy}/vacancyDescription', 'VacancyController@vacancyDescription')->name('vacancyDescription');

    Route::post('applicant/apCategory', 'SearchController@apCategory')->name('apCategory');
    Route::post('applicant/apTitle', 'SearchController@apTitle')->name('apTitle');

    Route::post('applicant/apRef', 'SearchController@apRef')->name('apRef');

    Route::post('company/cpName', 'SearchController@cpName')->name('cpName');


    Route::resource('interview', 'InterviewController');

    Route::get('applicant/{applicant}/interview', 'InterviewController@applicant')->name('app.interview');

    Route::get('applicant/{applicant}/mail', 'EmailController@create')->name('mail.create');

    Route::post('applicant/sendMail', 'EmailController@send')->name('mail.send');


    Route::resource('hire', 'HireController');
    Route::get('applicant/{applicant}/hired', 'HireController@applicant')->name('app.hire');

    Route::resource('reject', 'RejectController');
    Route::get('applicant/{applicant}/rejected', 'RejectController@applicant')->name('app.reject');
});

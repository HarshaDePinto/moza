<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Company;
use App\Applicant;
use App\Title;

class SearchController extends Controller
{
    public function apCategory(Request $request)
    {
        $data = $request->all();

        $category = Category::where('id', $data['category_id'])->firstOrFail();
        return view('applicants.apCategory')->with('applicants', Applicant::where('category_id', $data['category_id'])->get())->with('categoryName', $category)->with('categories', Category::orderBy('updated_at', 'desc')->get());
    }

    public function apTitle(Request $request)
    {
        $data = $request->all();

        $title = Title::where('id', $data['title_id'])->firstOrFail();
        return view('applicants.apTitle')->with('applicants', Applicant::where('title_id', $data['title_id'])->get())->with('titleName', $title)->with('categories', Category::orderBy('updated_at', 'desc')->get());
    }

    public function apRef(Request $request)
    {
        $data = $request->all();

        $applicants = Applicant::where('regNumber', 'LIKE', '%' . $data['regNumber'] . '%')->get();
        return view('applicants.apRef')->with('applicants', $applicants)->with('categories', Category::orderBy('updated_at', 'desc')->get());
    }

    public function cpName(Request $request)
    {
        $data = $request->all();

        $companies = Company::where('name', 'LIKE', '%' . $data['name'] . '%')->get();
        return view('companies.index')->with('companies', $companies);
    }
}
